// ハンバーガーメニューについてのjQuery
jQuery(function ($) {
  $('.js-hamburger').on('click', function(){
    if ($(this).hasClass('open')) {
      // ドロワーメニューが開いている時の処理
      $('.js-drawer').fadeOut();
      $(this).removeClass('open');
      $('html').removeClass('fixed');
    } else {
      // ドロワーメニューが閉じている時の処理
      $('.js-drawer').fadeIn();
      $(this).addClass('open');
      $('html').addClass('fixed');
    }
  });
});

// スライドショーについてのjQuery
$('.look__slider').slick({
		autoplay: true,//自動的に動き出すか。初期値はfalse。
		infinite: true,//スライドをループさせるかどうか。初期値はtrue。
		speed: 500,//スライドのスピード。初期値は300。
		slidesToShow: 3,//スライドを画面に3枚見せる
		slidesToScroll: 1,//1回のスクロールで1枚の写真を移動して見せる
		prevArrow: '<div class="slick-prev"></div>',//矢印部分PreviewのHTMLを変更
		nextArrow: '<div class="slick-next"></div>',//矢印部分NextのHTMLを変更
		centerMode: true,//要素を中央ぞろえにする
		variableWidth: true,//幅の違う画像の高さを揃えて表示
		dots: true,//下部ドットナビゲーションの表示
	});

  $(document).ready(function(){
    $("p.question").on("click", function() {
    $(this).next().slideToggle(200);
    });
    });

// TOPに戻るボタンについてのjQuery
    jQuery(function() {
      var pagetop = $('#topback');   
      pagetop.hide();
      $(window).scroll(function () {
          if ($(this).scrollTop() > 500) {  //500pxスクロールしたら表示
              pagetop.fadeIn();
          } else {
              pagetop.fadeOut();
          }
      });
      pagetop.click(function () {
          $('body,html').animate({
              scrollTop: 0
          }, 500); //0.5秒かけてトップへ移動
          return false;
      });
  });
  