jQuery(function ($) {
  $('.js-hamburger').on('click', function(){
    if ($(this).hasClass('open')) {
      // ドロワーメニューが開いている時の処理
      $('.js-drawer').fadeOut();
      $(this).removeClass('open');
      $('html').removeClass('fixed');
    } else {
      // ドロワーメニューが閉じている時の処理
      $('.js-drawer').fadeIn();
      $(this).addClass('open');
      $('html').addClass('fixed');
    }
  });
  // 最初のコンテンツ以外は非表示
  $(".accordion-content").css("display", "none");
  // $(".accordion-content.open").css("display", "block");
  // 矢印の向きを変えておく
  // $(".js-accordion-title:first-of-type").addClass("open");
 
  $(".js-accordion-title").click(function () {
    $(".open").not(this).removeClass("open").next().slideUp(300);
    $(this).toggleClass("open").next().slideToggle(300);
  });
});
